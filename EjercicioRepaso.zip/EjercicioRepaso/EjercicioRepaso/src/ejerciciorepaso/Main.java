
package ejerciciorepaso;

import Modelo.Producto;
import Modelo.ConsultasProducto;
import Controlador.ControladorPrincipal;
import Controlador.ControladorProducto;
import Vista.VPrincipal;
import Vista.VProducto;

public class Main {

    public static void main(String[] args) {
               
        Producto pro=new Producto();
        ConsultasProducto proC=new ConsultasProducto();
        VProducto frmPro=new VProducto();
        ControladorProducto ctrlPro=new ControladorProducto(pro, frmPro, proC);
        VPrincipal frmPri=new VPrincipal();
        ControladorPrincipal ctrlPri=new ControladorPrincipal(frmPri, frmPro);
        ctrlPri.iniciar();
        frmPri.setVisible(true);
    }
}